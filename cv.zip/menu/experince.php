<!--
	Imam Pirdaus
	namasayaimam@gmail.com
	-->
<table id="isi_konten3">
		<tr>
			<td><img src="images/asdp.png" class="img3"></td>
		</tr>

		<tr>
			<td><img src="images/ras.png" class="img3"></td>
		</tr>
	</table>
	<table id="isi_konten4">
		<tr>
			<td>
			<ul>
				<p>JAVA PROGRAMING    2015</p>
				<p>PT. ASDP Indonesia Ferry</p>
				<p>Analisa, Perancangan dan pembuatan</p>
				<p>project tunjangan karyawan.</p>
			</td>
		</tr>
		<tr>
			<td>
			<ul>
				<p>WEB PROGRAMING    2016</p>
				<p>RAS Foundation</p>
				<p>Pembuatan dan pengembangan</p>
				<p>web.</p>
			</td>
		</tr>
	</table>