<!--
	Imam Pirdaus
	namasayaimam@gmail.com
	-->
<table id="isi_konten5">
			<tr>
				<td><img src="images/email.png" class="img5"></img></td>
				<td><a href="http://namasayaimam@gmail.com">namasayaimam@gmail.com</a></td>
			</tr>
			<tr>
				<td><img src="images/telpon.png" class="img5"></img></td>
				<td><p>+62 838 9988 9896</p></td>
			</tr>
			<tr>
				<td><img src="images/linkedin.png" class="img5"></img></td>
				<td><a href="https://id.linkedin.com/in/imampirdaus">Imam Pirdaus</a></td>
			</tr>
		</table>