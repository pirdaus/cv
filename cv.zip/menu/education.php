<!--
	Imam Pirdaus
	namasayaimam@gmail.com
	-->
		<img src="images/bsi.png" class="img4" />
		<div id="text1">
			<p>Bina Sarana Informatika</p>
			<p>Manajemen Informatika D3 2016</p>
			<p></p>
		</div>