<!--
	Imam Pirdaus
	namasayaimam@gmail.com
	-->
<img src="images/IMAM.jpg" class="img1">

      <table id="isi_konten">
        <tr>
          <td><label>Nama</label></td>
          <td>:</td>
          <td><label>Imam Pirdaus</label></td>
        </tr>
        <br>
        <tr>
          <td><label>Tempat Lahir</label></td>
          <td>:</td>
          <td><label>Bekasi</label></td>
        </tr>
        <br>
        <tr>
          <td><label>Tanggal Lahir</label></td>
          <td>:</td>
          <td><label>12 Desember 1995</label></td>
        </tr>
        <br>
        <tr>
          <td><label>Alamat</label></td>
          <td>:</td>
          <td><label>Bekasi Indonesia</label></td>
        </tr>
      </table>