<?php
  $db = new PDO('mysql:host=127.0.0.1;dbname=databasename','user','password');
?>
<!--
	Imam Pirdaus
	namasayaimam@gmail.com
	-->